import java.io.*;

public class WebDev{

	private static File[] readFolder(){

		File folder = new File(".");
		File[] listOfFiles = folder.listFiles();
		return listOfFiles;
	}

	public static void writeToTxt(File[] files){

		String txt = "";

		for (int i = 0; i < files.length; i++) {
		  if (files[i].isFile()) 
		    txt = txt + files[i].getName() + "\n";
		}
        
        try {
            //create a temporary file
            
            File fileNames = new File("nomes.txt");

            // This will output the full path where the file will be written to...
            System.out.println(fileNames.getCanonicalPath());

            BufferedWriter writer = new BufferedWriter(new FileWriter(fileNames));
            writer.write(txt);
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

	public static void main(String[] args) {
		
		File[] files = readFolder();
		writeToTxt(files);


	}

}