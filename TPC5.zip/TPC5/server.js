var http = require('http')
var url = require('url')
var fs = require('fs')
var pug = require('pug')

var puburl = /\/mus\//

http.createServer((req,res)=>{
    var purl = url.parse(req.url,true)
    
    
    
    if((purl.pathname == "/") || (purl.pathname == "/index")){
        
        res.writeHead(200, {'Content-Type': 'text/html'})
        fs.readFile('obras-musicais-json/json/index.json', (erro, dados)=>{

            if(!erro)
                res.write(pug.renderFile('index.pug', {ind: JSON.parse(dados)}))
            else
                res.write(pug.renderFile('pagenotfound.pug', {}))
            res.end()
        })
    }

    else
        if(puburl.test(purl.pathname)){
            
            var ficheiro = purl.pathname.split('/')[2]
            res.writeHead(200, {'Content-Type': 'text/html'})
            fs.readFile('obras-musicais-json/json/' + ficheiro + '.json', (erro, dados)=>{
            
                if(!erro){
                    res.write(pug.renderFile('template.pug', {mus: JSON.parse(dados)}))
                }
                else
                    res.write(pug.renderFile('pagenotfound.pug', {}))
                res.end()
            })
        }

        else 
            if(purl.pathname == "/w3.css"){
                res.writeHead(200, {'Content-Type': 'text/css'})

                fs.readFile('stylesheet/w3.css', (erro, dados)=>{

                    if(!erro)
                        res.write(dados)
                    
                    else
                        res.write(pug.renderFile('pagenotfound.pug', {}))
                    res.end()
                })
            }

            else{
                res.writeHead(200, {'Content-Type': 'text/html'})
                res.write(pug.renderFile('pagenotfound.pug', {}))
                res.end()
            }
}).listen(5000, ()=>{
    console.log('Servidor à escuta na porta 5000...')
})