var http = require('http')
var url = require('url')
var fs = require('fs')
var pug = require('pug')
var jsonfile = require('jsonfile')

var {parse} = require('querystring')

var tarefasBD = 'tarefas.json'

var myServer = http.createServer((req,res)=>{
    
    var purl = url.parse(req.url, true)

    var query = purl.query

    console.log('Recebi pedido: ' + purl.pathname)
    console.log('Com o método: ' + req.method)

    if (req.method == 'GET'){
        if (purl.pathname == '/' || purl.pathname == '/index'){
            jsonfile.readFile(tarefasBD, (erro, trf)=>{
                if (!erro){  
                    res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
                    res.write(pug.renderFile('index.pug', {tarefas: trf}))
                    res.end()
                }
            })
        }
        else{
            if (purl.pathname == '/registo'){
                res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
                res.write(pug.renderFile('form-tarefa.pug'))
                res.end()
            }
            else{
                if (purl.pathname == '/verApagadas'){
                    jsonfile.readFile(tarefasBD, (erro, trf)=>{
                        if (!erro){
                            res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
                            res.write(pug.renderFile('tarefas-apagadas.pug', {tarefas: trf}))
                            res.end()
                        }
                    })
                }
                else{
                    if (purl.pathname == '/w3.css'){
                        res.writeHead(200, {'Content-Type': 'text/css'})
                        fs.readFile('stylesheet/w3.css', (erro, dados)=>{
                        
                            if(!erro)
                                res.write(dados)
                            
                            else
                                res.write(pug.renderFile('erro.pug', {e: erro}))
                            res.end()
                        })
        
                    }
            
                    else{
                        res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
                        res.write(pug.renderFile('erro.pug', {e: "Erro: " + purl.pathname + " não está implementado!"}))
                        res.end()
                        }
                    }
                }
            }
        }

    else{
        if (req.method == 'POST'){
            
            if (purl.pathname == '/processaForm'){
                recuperaInfo(req, resultado =>{
                    jsonfile.readFile(tarefasBD, (erro, tarefas)=>{
                        if (!erro){
                            resultado.id = tarefas.length
                            tarefas.push(resultado)
                            console.dir(tarefas)

                            jsonfile.writeFile(tarefasBD, tarefas, erro=>{
                                if (erro)
                                    console.log(erro)
                                else
                                    console.log('Registo gravado com sucesso na Base de Dados')
                                })
                        }

                        else{
                            res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
                            res.write(pug.renderFile('erro.pug', {e: "Erro na leitura da Base de Dados"}))
                            res.end()
                        }
                    })
                    res.end(pug.renderFile('tarefa-recebido.pug', {tarefa: resultado}))
                })
            }
            
            else{
                if (purl.pathname == '/apagarTarefa'){
                    recuperaInfo(req, resultado =>{
                        jsonfile.readFile(tarefasBD, (erro, tarefas)=>{
                            
                            if (!erro){
                                for (tarefa of tarefas)
                                    if (tarefa.id == resultado.id)
                                        tarefa.apagado = 1

                            jsonfile.writeFile(tarefasBD, tarefas, err=>{})
                                    if (erro)
                                        console.log('ERRO AO APAGAR UMA TAREFA')
                                    else
                                        console.log('Registo gravado com sucesso na Base de Dados')
                            }

                            else{
                                res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
                                res.write(pug.renderFile('erro.pug', {e: "Erro na leitura da Base de Dados"}))
                                res.end()
                            }
                            res.end(pug.renderFile('index.pug', {tarefas: tarefas}))
                            console.log(tarefas)
                        })
                    })
                }
                else{
                    res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
                    res.write(pug.renderFile('erro.pug', {e: "Erro: " + purl.pathname + " não está implementado!"}))
                    res.end()
                }
            }
        }

        else{
            res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})
            res.write(pug.renderFile('erro.pug', {e: "Método: " + req.method + " não está implementado!"}))
            res.end()
        }
    }
})

myServer.listen(4006,()=>{
    console.log('Servidor à escuta na porta 4006')
})

function recuperaInfo(request, callback){
    
    if (request.headers['content-type'] === 'application/x-www-form-urlencoded'){
    
        let body = ''
        request.on('data', bloco =>{
            body += bloco.toString()
        })

        request.on('end', ()=>{
            callback(parse(body))
        })
    }
    
    else
        callback(null)

}