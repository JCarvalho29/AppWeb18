var http = require('http')
var fs = require('fs')
var pug = require('pug')
var formidable = require('formidable')
var express = require ('express')
var logger = require('morgan')
var jsonfile = require ('jsonfile')

var app = express()
var indexFicheiros = 'index_ficheiros.json'

app.use(logger('combined'))


app.all('/',(req,res,next)=>{
    res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'})

    next()
})



app.get('/', (req, res)=>{
    jsonfile.readFile(indexFicheiros, (err, index)=>{
        console.dir(index)
        if (!err){
            res.write(pug.renderFile('form-ficheiro.pug', {ficheiros: index}))
            console.log ('HERE')
        }
        else{
            res.write(pug.renderFile('erro.pug', {e: err}))
            console.log ('ERROR')
        
        }
        res.end()    
    })
})

app.get(/\/Uploaded_Files/, function (req, res) {

    var options = {
      root: __dirname + '/Uploaded_Files/',
      dotfiles: 'deny',
      headers: {
          'x-timestamp': Date.now(),
          'x-sent': true
      }
    };
    
    var fileName = req.url.split('/')[2];
    res.sendFile(fileName, options, function (err) {
      if (err) {
        console.log('ERRO NO SENDFILE!!!!!!')
    } else {
        console.log('Sent:', fileName);
        res.end()
      }
    });
  });

app.get('/favicon.ico', (req,res)=>{})


app.get('/w3.css', (req, res)=>{
    res.writeHead(200, {'Content-Type': 'text/css; charset=utf-8'})
	fs.readFile('stylesheet/w3.css', (erro, dados)=>{
		if(!erro)
			res.write(dados)
		
		else
			res.write(pug.renderFile('erro.pug', {e: erro}))
		res.end()
	})
})

app.post('/', (req, res)=>{
    console.log ('POST /')

    var form = formidable.IncomingForm()

    form.parse(req, (err, fields, files)=>{
        if (!err){

            var fileName = files.ficheiro.name
            var filePath = files.ficheiro.path
            console.dir(fields)
            console.dir(files)

            var newFilePath = 'Uploaded_Files/' + fileName

            fs.rename(filePath, newFilePath, error=>{

                if (error)
                    res.write(pug.renderFile('erro.pug', {e: error}))
                
                else{
                    jsonfile.readFile(indexFicheiros, (erro, index)=>{
                        if (!erro){
                            var indexRow = {}
                            indexRow.path = newFilePath
                            indexRow.nome = fileName
                            indexRow.desc = fields.desc
                            index.push(indexRow)
                            jsonfile.writeFile(indexFicheiros, index, fail=>{
                                if (!fail)
                                    res.write(pug.renderFile('form-ficheiro.pug', {ficheiros: index}))
                                else
                                    res.write(pug.renderFile('erro.pug', {e: fail}))
        
                                res.end()                        
                            })
                            
                        }

                        else{
                            res.write(pug.renderFile('erro.pug', {e: erro}))
                            res.end()
                        }
         
                    })
                }
            })
        }
    })
})

app.all('*', (req,res)=>{
    res.redirect('http://localhost:4007/')
})


http.createServer(app).listen(4007, ()=>{
    console.log('Servidor à escuta na porta 4007...')
})
