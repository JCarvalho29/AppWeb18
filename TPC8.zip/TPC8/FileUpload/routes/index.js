var express = require('express');
var router = express.Router();
var jsonfile = require('jsonfile')
var formidable = require('formidable')
var fs = require('fs')

var filesDB = "public/Files.json"

/* GET home page. */
router.get('/', function(req, res) {
  console.log("ESTOU NO /")

  jsonfile.readFile(filesDB, (erro, index)=>{
    
    console.log("estou no jsonfile")
    if (!erro){
      console.log("SEM ERRO NO INDEX")
      res.render('index', {files : index});
    }
    else{
      console.log("ERRO NO INDEX")
      res.render('error', {e: erro})
    }
  })
});


router.get('/files', function(req, res, next) {
  
  console.log("GET IN /files")

  jsonfile.readFile(filesDB, (erro, files)=>{
    if(!erro){
      console.log("/file NAO DEU ERRO")
      console.dir(files)
      res.render('files', {f: files})
    }
    else{
      console.log("/file DEU ERRO") 
      res.render('error', {e: erro})
    }
  })
})

router.post('/file/guardar', function(req, res) {
  
  console.log("POST IN " + req.url)
  var form = new formidable.IncomingForm()

  
  console.log("ANTES DO PARSE")

  form.parse(req, (err, fields, files)=>{
    console.log("INICIO DO PARSE")

    if (!err){
      console.log("SEM ERRO PARSE")
      var fileName = files.ficheiro.name
      var filePath = files.ficheiro.path
      

      var newFilePath = __dirname + '/../public/Uploaded_Files/' + fileName
      console.log("NOVO LOG")
      console.log(fields.descricao)
      console.log(newFilePath)
      fs.rename(filePath, newFilePath, error=>{

          if (error){
            console.log("ERRO RENAME")
            res.render('erro')
          }
          else{
            console.log("SEM ERRO RENAME")
              jsonfile.readFile(filesDB, (erro, index)=>{
                  if (!erro){
                      var indexRow = {}
                      indexRow.path = newFilePath
                      indexRow.nome = fileName
                      indexRow.desc = fields.descricao
                      index.push(indexRow)
                      jsonfile.writeFile(filesDB, index, fail=>{
                          if (fail){
                            console.log("ERRO WRITE")
                            res.render('error', {e: fail})
                          }
                          else 
                            console.log("DEU CERTO")              
                      })
                  }

                  else{
                    console.log("ERRO READ")
                      res.render('error', {e: erro})
                  }
              })
          }
      })
    }
    else{
      console.log("ERRO PARSE")
      res.render('error', {e: err})
    }
    console.log("FIM DO PARSE")
  })
})

module.exports = router;
