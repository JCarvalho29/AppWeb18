$(()=>{
    $('#tabela').load('http://localhost:4008/files')

    $('#add').click(e =>{
        e.preventDefault()
        console.log("NO AJAX")
        ajaxPost()

    })

    function ajaxPost(){
        var data = new FormData($('#cont')[0])
        $.ajax({
            type: "POST",
            contentType: false,
            processData: false,
            url: "http://localhost:4008/file/guardar",
            data: data,
            success: p =>{

                alert(JSON.stringify(p))
                $('#tabela').append('<tr>\n' 
                                    + '<td>' + $('#file').val() + '</td>' 
                                    + '<td>' + $('#descricao').val() + '</td>' 
                                    + '</tr>')
                },
            error: e =>{
                console.log('Erro no post' + e.responseText)

            }
        })
        $('#file').val('')
        $('#descricao').val('')
    }
})