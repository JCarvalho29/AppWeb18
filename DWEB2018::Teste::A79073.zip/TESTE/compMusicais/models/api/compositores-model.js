var mongoose = require('mongoose')

var Schema = mongoose.Schema

var CompositorSchema = new Schema({
    id:{type: String, required:true},
    nome: {type: String, required: true},
    dataNasc: {type: String, required: false},
    dataObito: {type: String, required: false},
    periodo: {type: String, required: false},
    bio: {type: String, required: false}
})

module.exports = mongoose.model('Compositor', CompositorSchema, 'compMusicais')