var express = require('express')
var router = express.Router()
var querystring = require('querystring')

var Compositores = require('../../controllers/api/compositores-controller')

/* GET home page. */
router.get('/', (req, res) => {

    if (req.query.data && req.query.periodo){
        Compositores.consultar_dp(req.query.data, req.query.periodo)
        .then(dados => res.jsonp(dados))
        .catch(erro => res.status(500).send("ERRO NA CONSULTA DE COMPOSITORES POR DATA E PERIODO\n" + erro))
    }
    else{
        if (req.query.periodo){
            Compositores.consultar_periodo(req.query.periodo)
            .then(dados => res.jsonp(dados))
            .catch(erro => res.status(500).send("ERRO NA CONSULTA DE COMPOSITORES POR PERIODO\n" + erro))
        }
        else{
            Compositores.listar()
            .then(dados => res.jsonp(dados))
            .catch(erro => res.status(500).send("ERRO NA LISTAGEM DE COMPOSITORES\n" + erro))
        }
    }
})

router.get('/:id', (req, res) => {
    Compositores.consultar_id(req.params.id)
    .then(dados => res.jsonp(dados))
    .catch(erro => res.status(500).send("ERRO NA PESQUISA DO COMPOSITOR COM O ID: " + req.params.id + " \n" + erro))
})

module.exports = router;
