var Compositor = require('../../models/api/compositores-model')

const Compositores = module.exports

// Devolve a lista de obras

Compositores.listar = ()=>{
    return Compositor
            .find()
            .sort({nome: 1})
            .exec()
}

Compositores.consultar_id = i =>{
    return Compositor
            .find({id: i})
            .exec()
}

Compositores.consultar_periodo = p =>{
    return Compositor
            .find({periodo: p})
            .sort({nome: 1})
            .exec()
}

Compositores.consultar_dp = (d,p) =>{
    return Compositor
            .find({periodo: p, dataNasc:{$gt: d}})
            .sort({data: 1})
            .exec()
}