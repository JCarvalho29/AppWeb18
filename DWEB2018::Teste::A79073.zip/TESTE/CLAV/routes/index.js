var express = require('express');
var router = express.Router();
var axios = require('axios')
var querystring = require('querystring')

/* GET home page. */
router.get('/', (req, res) => {

  axios.get("http://clav-test.di.uminho.pt/api/classes/nivel/1")
  .then(dados =>{var d = dados.data
                console.log("\n\n" + d[0].titulo + "\n\n")
                res.render('index', {lista: d})})
  .catch(erro => res.status(500).send("ERRO AO OBTER AS CLASSES DE NÍVEL 1!\n" + erro))
  res.render('index', { title: 'Express' });
});

router.get('/classe/:classe', (req, res) => {

  axios.get("http://clav-test.di.uminho.pt/api/classes/" + req.params.classe)
  .then(dados =>{var d = dados.data
                res.render('classe', {classe: d})})
  .catch(erro => res.status(500).send("ERRO AO OBTER AS CLASSES DE NÍVEL 1!\n" + erro))
  res.render('index', { title: 'Express' });
});

module.exports = router;
