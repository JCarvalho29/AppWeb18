var Nobel = require("./../models/nobel")
var mongoose = require('mongoose')


module.exports.listar = ()=>{
    return Nobel
            .find({},{year:1, category:1, _id: 0})
            .exec()
}

module.exports.listarCategory = (cat)=>{
    return Nobel
            .find({category: cat}, {_id: 0})
            .exec()
}

module.exports.listarCategoryDate = (cat, date)=>{
    console.log("QUERO VER ISTO!!!!! " + typeof cat + typeof date)
    return Nobel
            .find({category: cat, year: {$gt: date}}, {_id: 0})
            .exec()
}

module.exports.listarID = (id)=>{
    return Nobel
            .aggregate([{$unwind : "$laureates"}, 
                        {$match :{'laureates.id': '960'}},
                        {$project: {_id: 0}}
                    ])
            .exec()
}

module.exports.listarDistinctCategory = ()=>{
    return Nobel
            .distinct("category")
            .exec()
}

module.exports.listarLaureados = ()=>{
    return Nobel
    .aggregate([{$unwind : "$laureates"}, 
                {$project: {year: 1, category:1, "laureates.firstname": 1, "laureates.surname": 1, _id: 0}}
            ])
            .sort({"laureates.firstname": 1, "laureates.surname": 1})
            .exec()
}