var mongoose = require('mongoose')

var Schema = mongoose.Schema

var LaureatesSchema = new Schema({
    id: {type: String},
    firstname: {type: String},
    surname: {type: String},
    motivation: {type: String},
    share: {type: String}
})

var NobelSchema = new Schema({
    year: {type: String},
    category: {type: String},
    overallMotivation: {type: String},
    laureates: [{type: LaureatesSchema}]
})


module.exports = mongoose.model('Nobel', NobelSchema, 'nobel')