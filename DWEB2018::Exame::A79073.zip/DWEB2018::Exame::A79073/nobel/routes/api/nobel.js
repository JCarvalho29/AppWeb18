var express = require('express');
var router = express.Router();
var querystring = require('querystring')
var Nobel = require('../../controllers/nobel')

router.get('/premios', (req,res) =>{

    if(req.query.categoria && req.query.data){
        Nobel.listarCategoryDate(req.query.categoria, req.query.data)
        .then(dados =>{
            console.log("DADOS RECOLHIDOS DA API /PREMIOS CATEGORIA DATA")
            console.dir(dados)
            res.jsonp(dados)
        })
        .catch(erroCD =>{
            console.log("ERRO NA QUERY A /PREMIO CATEGORIA DATA: " + erroCD)
            res.status(500).send("ERRO NA QUERY A /PREMIO CATEGORIA DATA: " + erroCD)
        })
    }
    else{
        if(req.query.categoria){

            Nobel.listarCategory(req.query.categoria)
            .then(dados =>{
                console.log("DADOS RECOLHIDOS DA API /PREMIOS CATEGORIA")
                console.dir(dados)
                res.jsonp(dados)
            })
            .catch(erroC =>{
                console.log("ERRO NA QUERY A /PREMIO CATEGORIA: " + erroC)
                res.status(500).send("ERRO NA QUERY A /PREMIO CATEGORIA: " + erroC)
            })
        }
        else{

            Nobel.listar()
            .then(dados =>{
                console.log("DADOS RECOLHIDOS DA API /PREMIOS")
                console.dir(dados)
                res.jsonp(dados)
            })
            .catch(erro =>{
                console.log("ERRO NA QUERY A /PREMIO: " + erro)
                res.status(500).send("ERRO NA QUERY A /PREMIO: " + erro)
            })
        }
    }
})

router.get('/premios/:id', (req,res) =>{

    Nobel.listarID(req.params.id)
    .then(dados =>{
        console.log("DADOS OBTIDOS NO /PREMIOS/:ID: ")
        console.dir(dados)
        res.jsonp(dados)
    })
    .catch(erroID =>{
        console.log("ERRO AO OBTER PREMIO POR ID: " + erroID)
        res.status(500).send("ERRO AO OBTER PREMIO POR ID: " + erroID)
    })

})

router.get('/laureados', (req,res) =>{

    Nobel.listarLaureados()
    .then(dados =>{
        console.log("DADOS OBTIDOS NO /LAUREADOS: ")
        console.dir(dados)
        res.jsonp(dados)
    })
    .catch(erroL =>{
        console.log("ERRO AO OBTER LAUREADOS: " + erroL)
        res.status(500).send("ERRO AO OBTER LAUREADOS: " + erroL)
    })

})

router.get('/categorias', (req,res) =>{

    Nobel.listarDistinctCategory()
    .then(dados =>{
        console.log("DADOS OBTIDOS NO /categorias: ")
        console.dir(dados)
        res.jsonp(dados)
    })
    .catch(erroL =>{
        console.log("ERRO AO OBTER categorias distintas: " + erroL)
        res.status(500).send("ERRO AO OBTER categorias distintas: " + erroL)
    })

})

module.exports = router;