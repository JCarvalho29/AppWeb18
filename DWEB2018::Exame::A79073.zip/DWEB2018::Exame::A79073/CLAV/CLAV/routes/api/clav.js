var express = require('express');
var axios = require('axios')
var querystring = require('querystring')
var router = express.Router();

router.get('/', (req, res) =>{
    console.log("HERE")
    axios.get('http://clav-test.di.uminho.pt/api/classes/nivel/1')
    .then(dados =>{
        console.log("DADOS DA / (NIVEL 1) ")
        console.dir(dados.data)
        res.jsonp(dados.data)
    })
    .catch(erroN1 =>{
        console.log("ERRO AO OBTER OS DADOS NO / (NIVEL 1) " + erroN1)
        res.status(500).send("ERRO AO OBTER OS DADOS NO / (NIVEL 1) " + erroN1)
    })
})

router.get('/info', (req, res) =>{
    console.log("ENTREI NO /INFO")
    var nivel = req.query.codigo.split(".").length

    console.log("CODIGO => " + req.query.codigo + " NIVEL => " + nivel.length)

    axios.get('http://clav-test.di.uminho.pt/api/classes/c' + req.query.codigo)
    .then(dados =>{
        console.log("DADOS DA /info ")
        var proc = {}
        proc.dados = dados.data[0]
        console.dir(proc)
        axios.get("http://clav-test.di.uminho.pt/api/classes/c" + req.query.codigo + "/descendencia")
        .then(descendencia =>{
            console.log("DESCENDENCIA")
            console.log(descendencia.data)
            proc.desc = descendencia.data
            
            if(nivel == 3){
                console.log("É de nível 3")
                axios.get("http://clav-test.di.uminho.pt/api/classes/c" + req.query.codigo + "/procRel")
                .then(procRel =>{
                    console.log("PROCESSOS RELACIONADOS!!!!!!!!")
                    console.dir(procRel.data)
                    proc.nivel3 = true
                    proc.procRel = procRel.data

                    res.jsonp(proc)
                })
                .catch(erroProcRel =>{
                    console.log("ERRO AO OBTER OS PROCESSOS RELACIONADOS AO PROCESSO " + req.query.codigo)
                    res.status(500).send("ERRO AO OBTER OS PROCESSOS RELACIONADOS AO PROCESSO " + req.query.codigo)
                })
            }
            else{
                console.log("NÃO É DE NÍVEL 3")
                proc.procRel = []
                proc.nivel3 = false
                res.jsonp(proc)
            }

        })
        .catch(erroDesc =>{
            console.log("ERRO AO CONSULTAR A DESCENDENCIA DE UM PROCESSO " + erroDesc)
            res.status(500).send("ERRO AO CONSULTAR A DESCENDENCIA DE UM PROCESSO " + erroDesc)
        })
    })
    .catch(erroinfo =>{
        console.log("ERRO AO OBTER OS DADOS NO /info " + erroinfo)
        res.status(500).send("ERRO AO OBTER OS DADOS NO /info " + erroinfo + req.query.codigo)
    })
})


module.exports = router;
