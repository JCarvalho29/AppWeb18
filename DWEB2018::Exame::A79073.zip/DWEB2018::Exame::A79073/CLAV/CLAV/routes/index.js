var express = require('express');
var axios = require('axios');
var router = express.Router();
var querystring = require('querystring')

/* GET home page. */
router.get('/', function(req, res) {
  axios.get('http://localhost:3000/api/clav')
  .then(dados =>{
    console.log("DADOS OBTIDOS NO / (NIVEL 1) ")
    console.dir(dados.data)
    res.render('index', {n1:dados.data})
  })
  .catch(erro =>{
    console.log("ERRO NA CONSULTA DA API /API/CLAV/ (NIVEL 1)" + erro)
    res.status(500).send("ERRO NA CONSULTA DA API /API/CLAV/ (NIVEL 1)" + erro)
  })
});

router.get('/info', function(req, res) {
  console.log("CÓDIGO " + req.query.codigo)
  axios.get('http://localhost:3000/api/clav/info?codigo=' + req.query.codigo)
  .then(dados =>{
    console.log("DADOS OBTIDOS NO /info ")
    console.dir(dados.data)
    var pA = null
    if (req.query.origem)
      pA = "http://localhost:3000/info?codigo=" + req.query.origem
    else
      pA = "http://localhost:3000/"
    res.render('info', {codigo:dados.data, pagAnterior: pA})
  })
  .catch(erro =>{
    console.log("ERRO NA CONSULTA DA API /API/CLAV/info" + erro)
    res.status(500).send("ERRO NA CONSULTA DA API /API/CLAV/info" + erro)
  })
});

module.exports = router;
